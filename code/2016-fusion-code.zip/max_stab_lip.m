function [C, delta, epsilonInit] = max_stab_lip(af, ah, qHat, rHat, maxError, betaPar, linearPart, optimize)
% MAX_STAB_LIP  Computes the largest Lipschitz constant of non-linear part of a system such that an exact non-linear
%               Kalman filter for this system is stable. See the article [1]. Works with
%               univariate models only.
%               
%               All references in parentheses are to the article [1].
%
%  This function can be used for non-linear models of the form
%     x_k = a_f * x_(k-1) + g_f(x_(k-1) + q_(k-1),
%     y_k = a_h * x_k + g_h(x_k) + r_k,
%   with a_f and a_h some constants and g_f and g_h Lipschitz continuous and either g_f = 0 or g_h = 0 (i.e. either the dynamic model
%   or the measurement model must be linear). Calculates the maximal Lipschitz constant of g_f or g_h for which the non-linear Kalman
%   filter stability results work (see (16) and (17) for the most critical conditions). Also computes delta, the maximal noise
%   standard deviation (i.e. q_(k-1), r_k ~ N(0, delta^2)), and epsilonInit, the maximal L^2 norm of predicted estimation error 
%   at time-step k = 1.
%
% ARGUMENTS
%   af          linear part of dynamic model
%   ah          linear part of measurement model
%   qHat        dynamic model noise variance tuning parameter
%   rHat        measurement model noise variance tuning parameter
%   betaPar     tuning parameter beta, usual value is betaPar = 2, but can be set to anything > 1
%   maxError    desired upper bound for L^2 norm of predicted estimation error (\tilde{epsilon} in the article)
%   linearPart  which part, dynamic or measurement model, is linear ('f' for dynamic model, 'h' for measurement model)
%   optimize    (optional) whether to use values optimized for the univariate case instead of general ones (1 if yes, otherwise no),
%               see the second-to-last paragraph of Sec. VII
%
%
% RETURNS
%   C           the maximal Lipschitz constant of the non-linear part that guarantees stability
%   delta       maximum value of true noise variances (i.e. q_(k-1) and r_k), if negative stability cannot be guaranteed
%   initError   maximum value L^2 norm of predicted estimation error at time-step k = 1
%
%
% REFERENCES
%   [1]   T. Karvonen and S. Särkkä, "Fourier-Hermite series for stochastic stability analysis of non-linear Kalman filters,"
%         in 19th International Conference on Information Fusion (FUSION), pp. 1829-1836, 2016.
%
%
%   Toni Karvonen (30 August, 2016)

%%%% Argument validity checks

  if betaPar <= 1
    error('Value of betaPar must be > 1')
  end

  if strcmp(linearPart, 'f')
    fNonlLip = 0;
    hNonlLip = 1;
  elseif strcmp(linearPart, 'h')
    hNonlLip = 0;
    fNonlLip = 1;
  else
    error('Argument ''linearPart'' must be set as either ''f'' or ''h''')
  end

  if ~exist('optimize', 'var') | optimize ~= 1
    optimize = 0;
  end

%%%%

%%%% Use binary search on interval [0,1] to find the largest Lipschitz C constant for which stability is guaranteed

  C = 0.5;
  l = 0.5;
  
  while l > 1e-6
    l = l / 2;
    if stab_consts(af, ah, C * fNonlLip, C * hNonlLip, qHat, rHat, betaPar, maxError, optimize)
      C = C + l;
    else
      C = C - l;
    end
  end
  
  % Select C - l just to be sure to get a Lipschitz constant that guarantees stability
  C = C - l;
  [is_stable, delta, epsilonInit] = stab_consts(af, ah, C, 0, qHat, rHat, betaPar, maxError, optimize);
  
%%%%

end

