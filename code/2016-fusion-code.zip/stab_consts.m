function [is_stable, delta, epsilonInit] = stab_consts(af, ah, fNonlLip, hNonlLip, qHat, rHat, betaPar, maxError, optimize)
% STAB_CONSTS   Computes non-linear Kalman filter stability related parameters of the article [1] for univariate
%               model with dynamic model and measurement model functions Lipschitz continuous.
%               
%               All references in parentheses are to the article [1].
%
%  This function can be used for non-linear models of the form
%     x_k = a_f * x_(k-1) + g_f(x_(k-1) + q_(k-1),
%     y_k = a_h * x_k + g_h(x_k) + r_k,
%   with a_f and a_h some constants and g_f and g_h Lipschitz continuous. For given parameters the function uses (16) and (17) 
%   to calculate if stability of the exact non-linear Kalman filter for the model can be guaranteed. Also computes delta, the
%   maximal noise standard deviation (i.e. q_(k-1), r_k ~ N(0, delta^2)).
%
% ARGUMENTS
%   af          linear part of dynamic model
%   ah          linear part of measurement model
%   fNonlLip    Lipschitz constant of the non-linear part of dynamic model (i.e. g_f)
%   hNonlLip    Lipschitz constant of the non-linear part of measurement model (i.e. g_h)
%               NOTE: The function assumes that there are no problematic cancellations between af or ah and g_f or g_h, i.e.
%                     it assumed that the maximal Lipschitz constant of the whole dynamic model can be computed as
%                     abs(af) + abs(fNonlLip) and that the minimal absolute value of measurement model derivative is abs(ah).
%   qHat        dynamic model noise variance tuning parameter
%   rHat        measurement model noise variance tuning parameter
%   betaPar     tuning parameter beta, usual value is betaPar = 2, but can be set to anything > 1
%   maxError    desired upper bound for L^2 norm of predicted estimation error (\tilde{epsilon} in the article)
%   optimize    (optional) whether to use values optimized for the univariate case instead of general ones (1 if yes, otherwise no),
%               see the second-to-last paragraph of Sec. VII
%
%
% RETURNS
%   delta       maximum value of true noise variances (i.e. q_(k-1) and r_k), stability cannot be guaranteed if negative
%   initError   maximum value L^2 norm of predicted estimation error at time-step k = 1
%   is_stable   1 if stability can be guaranteed, 0 otherwise (based on inequalities (16) and (17))
%
%
% REFERENCES
%   [1]   T. Karvonen and S. Särkkä, "Fourier-Hermite series for stochastic stability analysis of non-linear Kalman filters,"
%         in 19th International Conference on Information Fusion (FUSION), pp. 1829-1836, 2016.
%   [2]   B.D.O. Anderson and J.B. Moore, Optimal Filtering. Prentice-Hall, 1979.
%
%
%   Toni Karvonen (30 August, 2016)

%%%% Argument validity checks

  if betaPar <= 1
    error('Value of betaPar must be > 1')
  end

  if ~exist('optimize', 'var') | optimize ~= 1
    optimize = 0;
  end

%%%%

%%%% Some system parameters

  % State and measurement dimensions (the whole thing works in one dimension anyway)
  dimY = 1;
  dimX = 1;
  % Lipschitz constant of f (see note in ARGUMENTS documentation)
  fLip = abs(af) + abs(fNonlLip);
  % Minimum of absolute value of derivative of h (see note in ARGUMENTS documentation)
  h1 = abs(ah);
  
%%%%

%%%% Compute the steady state predicted covariance of the upper bounding linear system
  % This is done by setting two consecutive univariate linear Kalman filter variances equal and 
  % solving the resulting quadratic equation. See e.g. p. 83 of [2].
  pmSteady = max( roots([h1^2; rHat - rHat * fLip^2 - qHat * h1^2; -qHat * rHat]) );
%%%%

%%%% Compute parameters of non-linear KF stability result of Theorem 4

  %%% Parameters in Assumptions (1) and (2) that have not already been defined
    % Error covariance bounds
    pmUp = pmSteady;
    pmLow = qHat; % This is probably not very good lower bound but the most obvious
    pUp = pmSteady;
    % Non-linearity parameters of Assumption 2 of Theorem 4 (see Remark (4) after theorem statement)
    kappaPhi = 2 * fNonlLip; % That of g_f
    kappaChi = 2 * hNonlLip; % That of g_h
    kappaPhiPlus = fNonlLip * pmUp; % That of g_f
    kappaChiPlus = hNonlLip * pmUp; % That of g_h
    
  %%% Computations
  
    %% Upper bound for the matrix A = I - KH
      if optimize
        A = 1;
      else
        A = pUp / pmLow;
      end
  
    %% Upper bound of the Kalman gain matrix from Lemma 5
      if optimize
        K = 0.5 * sqrt(pmUp / rHat);
      else
        K = pmUp / (pmLow * sqrt(rHat));
      end
      
    %% Lemma 6 (alpha')
      alphaDot = qHat / (pUp * fLip^2 + qHat);
    
    %% Lemma 7 (kappa^rhos)
      % Auxiliary variables
      kappa1 = A * kappaPhi + K * kappaChi * kappaPhi + K * fLip * kappaChi;
      kappa2 = K * kappaPhi * sqrt(dimY);
      kappaPlus = kappaPhiPlus + (kappaPhi + fLip) * K * kappaChiPlus;

      % Kappa^rhos
      kappa1Rho = (kappa1 / pmLow) * ( kappa1 +  2 * A * fLip );
      kappa2Rho = (2 * kappa2 / pmLow) * ( kappa1 + A * fLip );
      kappa3Rho = ( (dimY * kappaPhi^2) / rHat ) * (pmUp / pmLow)^2;
      kappa4Rho = ( (2 * kappaPlus) / pmLow ) * ( A * fLip + kappa1 );
      kappa5Rho = (2 * kappa2 * kappaPlus) / pmLow;
      kappa6Rho = kappaPlus^2 / pmLow;
    
    %% Lemma 8 (kappa^sigma)
      kappaSigma = (1/pmLow) * (dimX + (dimY * (fLip * pmUp)^2) / rHat );

    %% Upper bound for delta (Proof of Theorem 4)
    delta = max( roots([kappa3Rho + kappaSigma; kappa2Rho * maxError + kappa5Rho; kappa4Rho * maxError + kappa6Rho - ( (betaPar - 1) * alphaDot * maxError^2) / (2 * pmUp * betaPar)]) );

    %% Upper bound for the size of mean square of xi_1^-
    epsilonInit = (pmLow * maxError^2) / (2 * pmUp);

%%%%

%%%% Determine if the system is stable
  
  is_stable = 1;
  
  % If delta has no positive real solutions stability cannot be guaranteed, cf. (16)
  if ~isreal(delta) | delta <= 0
    is_stable = 0;
  end
  
  % If (17) does not hold, stability cannot be guaranteed
  if (pmUp * kappa1Rho) > (alphaDot / betaPar)
    is_stable = 0;
  end
  
%%%%

end

